﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using MapGen;
using System.Linq;

public class Node
{
    public Node cameFrom = null; //parent node
    public double priority = 0; // F value
    public double costSoFar = 0; // G Value
    public Tile tile;

    public Node(Tile _tile, double _priority, Node _cameFrom, double _costSoFar)
    {
        cameFrom = _cameFrom;
        priority = _priority; 
        costSoFar = _costSoFar;
        tile = _tile;
    }
}

public class PathFinder
{
    List<Node> TODOList = new List<Node>();
    List<Node> DoneList = new List<Node>();
    Tile goalTile = null;
    GameObject enemy1, enemy2, enemy3 = null;
    

    public PathFinder()
    {
    }

    // TODO: Find the path based on A-Star Algorithm
    public Queue<Tile> FindPathAStar(Tile start, Tile goal)
    {
        goalTile = goal; // Initialize the goalTile
        Node startNode = new Node(start, HeuristicsDistance(start, goal), null, 0); // Initializes the startNode
        TODOList.Add(startNode); // Add the startNode to the TODO List
        double minF = 1000; // minF = smallest F value
        double minG = 1000;  // minG = smallest G value

        // While loop to traverse the TODO List that will stop when
        // the goalTile has been added, thus an optimal path with the
        // smallest cost has been found.
        while (TODOList.Count != 0 || !CheckList(goalTile, TODOList))
        {
            // Finds the node in TODO List with the smallest F value
            foreach (Node n in TODOList)
            {
                n.priority = CalcCostSoFar(startNode.tile, n.tile, startNode.costSoFar) + HeuristicsDistance(n.tile, goalTile);
                if (n.priority < minF) // If the F value for n is smaller than minF, n becomes the new minF.
                {
                    minF = n.priority;
                    startNode = n;
                }
            }
            Node tracker = startNode;

            TODOList.Remove(tracker); // Removes the tracker node from the TODO List
            DoneList.Add(tracker); // Adds the tracker node to the Done List

            foreach (Tile t in tracker.tile.Adjacents)
            {
                // IS walkable and is NOT on the Done List
                if (t.mapTile.Walkable && !CheckList(t, DoneList))
                {
                    if (!CheckList(t, TODOList))
                    {
                        // Make a new node for the tile
                        Node nNode = new Node(t, (CalcCostSoFar(tracker.tile, t, tracker.costSoFar) + HeuristicsDistance(t, goalTile)),
                            tracker, CalcCostSoFar(tracker.tile, t, tracker.costSoFar));

                        // Add the node to the TODO List
                        TODOList.Add(nNode);
                    }
                    else
                    {
                        Node findNode = null;
                        foreach (Node n in TODOList)
                        {
                            if (n.tile == t)
                            {
                                findNode = n;
                            }
                        }
                        double nodeGCost = findNode.costSoFar;
                        foreach (Node n2 in TODOList)
                        {
                            if (n2.costSoFar < minG)
                            {
                                minG = n2.costSoFar;
                            }
                        }
                        if (nodeGCost == minG)
                        {
                            // Recalculate both the F and G costs for the tileNode
                            findNode.costSoFar = CalcCostSoFar(tracker.tile, t, tracker.costSoFar);
                            findNode.priority = findNode.costSoFar + HeuristicsDistance(tracker.tile, goalTile);
                            findNode.cameFrom = tracker;
                        }


                    }
                }
            }
        }
        // If the TODO List has nothing in it, then an empty Queue/Path will be returned
        if (TODOList.Count == 0)
        {
            return new Queue<Tile>(); // Returns an empty Path
        }
        else
        {
            // Make the goalTile a node
            Queue<Tile> nodeList = new Queue<Tile>();
            Node tdNode = TODOList[TODOList.Count - 1];
            Node finNode = new Node(goalTile, CalcCostSoFar(tdNode.tile, goalTile, tdNode.costSoFar), null,
                CalcCostSoFar(tdNode.tile, goalTile, tdNode.costSoFar));
            TODOList.Add(finNode);
            Node goalNode = TODOList[TODOList.Count - 1];
            goalNode.cameFrom = DoneList[DoneList.Count - 1];
            while (goalNode.cameFrom != null)
            {
                nodeList.Enqueue(goalNode.tile);
                goalNode = goalNode.cameFrom;
            }
            Queue<Tile> returnPath = new Queue<Tile>(nodeList.Reverse());
            return returnPath;
        }
    }

    // Receives a tile and a specified list and determines
    // whether that tile is in the list or not
    public bool CheckList(Tile t, List<Node> list)
    {
        foreach (Node n in list)
        {
            if (n.tile == t)
            {
                return true;
            }
        }
        return false;
    }

    // Calculates the cost of the tiles travelled so far - G cost
    public double CalcCostSoFar(Tile parent, Tile target, double parentG)
    {
        if (parent == null)
        {
            return 0;
        }
        if (parent.indexX == target.indexX)
        {
            return (parentG + 10);
        }
        if (parent.indexY == target.indexY)
        {
            return (parentG + 10);
        }
        return (parentG + 14);
    }


    // TODO: Find the path based on A-Star Algorithm
    // In this case avoid a path passing near an enemy tile
    public Queue<Tile> FindPathAStarEvadeEnemy(Tile start, Tile goal)
    {
        while (TODOList.Count != 0 || !CheckList(goalTile, TODOList))
        {

        }
       return new Queue<Tile>(); // Returns an empty Path
    }

    // Manhattan Distance with horizontal/vertical cost of 10
    double HeuristicsDistance(Tile currentTile, Tile goalTile)
    {
        int xdist = Math.Abs(goalTile.indexX - currentTile.indexX);
        int ydist = Math.Abs(goalTile.indexY - currentTile.indexY);
        // Assuming cost to move horizontally and vertically is 10
        //return manhattan distance
        return (xdist * 10 + ydist * 10);
    }


    // Retrace path from a given Node back to the start Node
    Queue<Tile> RetracePath(Node node)
    {
        List<Tile> tileList = new List<Tile>();
        Node nodeIterator = node;
        while (nodeIterator.cameFrom != null)
        {
            tileList.Insert(0, nodeIterator.tile);
            nodeIterator = nodeIterator.cameFrom;
        }
        return new Queue<Tile>(tileList);
    }

    // Generate a Random Path. Used for enemies
    public Queue<Tile> RandomPath(Tile start, int stepNumber)
    {
        List<Tile> tileList = new List<Tile>();
        Tile currentTile = start;
        for (int i = 0; i < stepNumber; i++)
        {
            Tile nextTile;
            //find random adjacent tile different from last one if there's more than one choice
            if (currentTile.Adjacents.Count < 0)
            {
                break;
            }
            else if (currentTile.Adjacents.Count == 1)
            {
                nextTile = currentTile.Adjacents[0];
            }
            else
            {
                nextTile = null;
                List<Tile> adjacentList = new List<Tile>(currentTile.Adjacents);
                ShuffleTiles<Tile>(adjacentList);
                if (tileList.Count <= 0) nextTile = adjacentList[0];
                else
                {
                    foreach (Tile tile in adjacentList)
                    {
                        if (tile != tileList[tileList.Count - 1])
                        {
                            nextTile = tile;
                            break;
                        }
                    }
                }
            }
            tileList.Add(currentTile);
            currentTile = nextTile;
        }
        return new Queue<Tile>(tileList);
    }

    private void ShuffleTiles<T>(List<T> list)
    {
        // Knuth shuffle algorithm :: 
        // courtesy of Wikipedia :) -> https://forum.unity.com/threads/randomize-array-in-c.86871/
        for (int t = 0; t < list.Count; t++)
        {
            T tmp = list[t];
            int r = UnityEngine.Random.Range(t, list.Count);
            list[t] = list[r];
            list[r] = tmp;
        }
    }
}
