
There is a problem with Unity not working. I cannot finish this project because I have no idea how to test this code when Unity stops responding every time I run it. I've rewritten the pathfinding script multiple times in different ways to see what the problem was, and I have had no luck in finding them. 

Please be a bit forgiving when grading this if possible. I have worked tirelessly on what I have so far, and have already had to start over 5 times due to these unknown issues. 	